import React from 'react'
import './Info.css'

const Info = () => {
    return (
        <div className='info-container'>
            <div className="info">
                <h1>Let the force be with U</h1>
            </div>
        </div>
    )
}

export default Info
